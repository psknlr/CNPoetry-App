"""领域引擎：规则库装载 + 荐诗/对比/教学/全息/研究。

Engine 是所有工具与服务端的共享只读核心：一次装载 poems 与全部规则
资产，提供带证据的领域操作。所有返回值都是可 JSON 化的 dict，
且凡涉及论断处均携带 poem_id 与 quote。
"""
from __future__ import annotations

import json
from collections import Counter
from typing import Dict, List, Optional

from .. import config
from ..corpus import normalize, sources
from ..extract import metrics as metrics_mod
from ..lexicon import IMAGERY, MOOD_HINTS, THEMES, IMAGERY_SURFACE, EMOTION_SURFACE
from ..rag.poem_rag import PoemRAG
from ..schemas import Poem, read_jsonl
from ..textutil import content_only, t2s

import re as _re
RE_POEM_ID_ONLY = _re.compile(r"^CNP_[A-Z0-9]+_\d{5}$")


class Engine:
    """只读领域核心（懒加载单例见 get_engine）。"""

    def __init__(self):
        self.poems: List[Poem] = normalize.load_poems()
        if not self.poems:
            from ..health import MissingAssetsError
            raise MissingAssetsError(
                "规则库未生成：请先运行 `python3 -m hermes_poetry pipeline`，"
                f"或设 HERMES_POETRY_DATA 指向数据目录（当前 {config.DATA_DIR}）。")
        self.by_id: Dict[str, Poem] = {p.poem_id: p for p in self.poems}
        self.rag = PoemRAG(self.poems, cache_fingerprint=self._corpus_fingerprint())
        self.imagery_profiles = {r["imagery"]: r for r in read_jsonl(config.RULES_IMAGERY_DIR / "imagery_profiles.jsonl")}
        self.theme_profiles = {r["theme"]: r for r in read_jsonl(config.RULES_THEME_DIR / "theme_profiles.jsonl")}
        self.cipai_profiles = {t2s(r["cipai"]): r for r in read_jsonl(config.RULES_CIPAI_DIR / "cipai_profiles.jsonl")}
        self.author_profiles = {t2s(r["author"]): r for r in read_jsonl(config.RULES_AUTHOR_DIR / "author_profiles.jsonl")}
        self.rhyme_rules = read_jsonl(config.RULES_RHYME_DIR / "rhyme_partners.jsonl")
        self.intertext_rules = read_jsonl(config.RULES_INTERTEXT_DIR / "intertext_rules.jsonl")
        self.external = {str(e.get("id")): e for e in sources.load_external_analysis()}
        self.shuowen = sources.load_shuowen()
        self.erya = sources.load_erya_glosses()
        self._erya_index: Dict[str, List[int]] = {}
        for i, g in enumerate(self.erya):
            for m in g["members"]:
                if len(m) == 1:
                    self._erya_index.setdefault(t2s(m), []).append(i)
        self._load_external_bindings()
        try:
            self.manifest = json.loads((config.MANIFEST_DIR / "corpus_manifest.json").read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            self.manifest = {}

    def _load_external_bindings(self) -> None:
        """D层绑定表：流水线单独落盘的小文件，免于全量扫描 initial_rules。"""
        self._ext_by_poem: Dict[str, Dict] = {}
        bindings = read_jsonl(config.RULES_INITIAL_DIR / "external_bindings.jsonl")
        if bindings:
            for b in bindings:
                ext = self.external.get(str(b.get("external_id", "")))
                if ext:
                    self._ext_by_poem[b["poem_id"]] = ext
            return
        # 兼容旧资产：回退全量扫描
        for r in read_jsonl(config.RULES_INITIAL_DIR / "initial_rules.jsonl"):
            if r.get("rule_type") == "external_analysis_rule":
                ext = self.external.get(str(r["if_conditions"].get("external_id", "")))
                if ext:
                    self._ext_by_poem[r["poem_id"]] = ext

    @staticmethod
    def _corpus_fingerprint() -> str:
        """poems.jsonl 的轻量指纹（大小+mtime），语料变更即缓存失效。"""
        try:
            st = (config.POEM_DIR / "poems.jsonl").stat()
            return f"{st.st_size}:{int(st.st_mtime)}"
        except OSError:
            return ""

    # ── 基础 ────────────────────────────────────────────────────
    @staticmethod
    def err(code: str, message: str, recoverable: bool = True, **extra) -> Dict:
        """结构化错误（供前端/智能体/调用方恢复），保留 message 便于展示。"""
        e = {"code": code, "message": message, "recoverable": recoverable}
        e.update(extra)
        return {"error": e}

    def resolve_candidates(self, title: str) -> List[Poem]:
        """同题候选（消歧卡片用）。"""
        return self.rag.find_by_title(title)

    def resolve(self, ref: str) -> Dict:
        """统一消歧结果：{status: unique|ambiguous|not_found, candidates, selected}。

        歧义口径（第三轮复审收紧）：同题多首即歧义——含**同作者同题**
        （组诗/同题异作）与**同作者同题异文**（版本歧义，如两种《静夜思》），
        不再以「作者不同」为歧义唯一条件。消歧语法：
          《题名》@作者          作者唯一一首时定解
          《题名》@作者#首句片段  版本/组诗定解
          poem_id               精确定解
        """
        bare = (ref or "").strip()
        first_hint = ""
        if "#" in bare:
            bare, _, first_hint = bare.partition("#")
            bare = bare.strip()
            first_hint = t2s(first_hint.strip())
        if bare.startswith("CNP_") or (("@" not in bare) and RE_POEM_ID_ONLY.match(bare or "")):
            p = self.resolve_poem(bare)
            return ({"status": "unique", "selected": p, "candidates": [p]} if p
                    else {"status": "not_found", "selected": None, "candidates": []})
        author_hint = ""
        if "@" in bare:
            title_part, _, author_hint = bare.partition("@")
            author_hint = t2s(author_hint.strip())
            bare = title_part.strip()
        cands = self.resolve_candidates(bare)
        if author_hint:
            cands = [c for c in cands if t2s(c.author) == author_hint]
        if first_hint:
            from ..textutil import contains_verbatim
            cands = [c for c in cands
                     if c.lines and contains_verbatim(c.lines[0], first_hint)]
        if not cands:
            p = self.resolve_poem(ref)
            return ({"status": "unique", "selected": p, "candidates": [p]} if p
                    else {"status": "not_found", "selected": None, "candidates": []})
        if len(cands) == 1:
            return {"status": "unique", "selected": cands[0], "candidates": cands}
        # 多候选：正文相同的重复才视为同一（保守），否则歧义
        texts = {content_only(t2s(c.text)) for c in cands}
        if len(texts) == 1:
            return {"status": "unique", "selected": cands[0], "candidates": cands}
        return {"status": "ambiguous", "selected": None, "candidates": cands[:8]}

    def require_unique(self, ref: str):
        """工具层统一入口：唯一 → Poem；否则结构化错误（含消歧提示）。

        业务模块不得再直接调用 resolve_poem 静默取首。"""
        res = self.resolve(ref)
        if res["status"] == "unique":
            return res["selected"], None
        if res["status"] == "ambiguous":
            return None, self.err(
                "POEM_AMBIGUOUS",
                f"「{ref}」有多首候选（含同作者同题/异文版本），请用 @作者 或 @作者#首句 定解",
                candidates=[{"poem_id": c.poem_id, "author": c.author, "dynasty": c.dynasty,
                             "book": c.book,
                             "first_line": c.lines[0] if c.lines else "",
                             "ref": f"《{c.title}》@{c.author}#" + (c.lines[0][:5] if c.lines else "")}
                            for c in res["candidates"][:6]])
        return None, self.err("POEM_NOT_FOUND", f"无法解析作品「{ref}」")

    def resolve_poem(self, ref: str) -> Optional[Poem]:
        """支持消歧语法：《题名》@作者（如 《春晓》@孟浩然）。"""
        ref = (ref or "").strip()
        if ref in self.by_id:
            return self.by_id[ref]
        import re
        m = re.search(r"CNP_[A-Z0-9]+_\d{5}", ref)
        if m and m.group(0) in self.by_id:
            return self.by_id[m.group(0)]
        author_hint = ""
        if "@" in ref:
            ref, _, author_hint = ref.partition("@")
            ref = ref.strip()
            author_hint = t2s(author_hint.strip())
        title = ref.strip("《》〈〉")
        if author_hint:
            cands = [p for p in self.resolve_candidates(title) if t2s(p.author) == author_hint]
            if cands:
                return cands[0]
        hits = self.rag.search(f"《{title}》", top_k=1)
        if hits and hits[0]["match_source"] == "direct_title":
            return self.by_id[hits[0]["poem_id"]]
        # 模糊题名回退：语料题名常带组诗编号（如「月下獨酌四首 一」）。
        # 前缀匹配优先；子串包含仅限 ≥3 字查询（短语/人名误解析防线）
        title_s = t2s(title)
        if len(title_s) >= 2:
            prefix_matches = self.rag.titles_containing(title_s, prefix_only=True)
            if not prefix_matches and len(title_s) >= 3:
                prefix_matches = self.rag.titles_containing(title_s)
            if prefix_matches:
                curated = [p for p in prefix_matches
                           if p.source in ("TANG300", "SONGCI300", "QIANJIA") or p.also_in]
                return (curated or prefix_matches)[0]
        return None

    def stats(self) -> Dict:
        return {
            "poems": len(self.poems),
            "sources": {k: v for k, v in (self.manifest.get("per_source") or {}).items()},
            "form_distribution": self.manifest.get("form_distribution", {}),
            "rules": self.manifest.get("rules", {}),
            "imagery_profiles": len(self.imagery_profiles),
            "theme_profiles": len(self.theme_profiles),
            "cipai_profiles": len(self.cipai_profiles),
            "author_profiles": len(self.author_profiles),
            "rhyme_groups": len(self.rhyme_rules),
            "intertext_rules": len(self.intertext_rules),
            "external_analysis_linked": len(self._ext_by_poem),
        }

    # ── 情境荐诗 ─────────────────────────────────────────────────
    def match(self, mood: str = "", imagery: Optional[List[str]] = None,
              themes: Optional[List[str]] = None, top_k: int = 6) -> Dict:
        # 用户传入的意象/题材先归一：表面形式（明月）→规范名（月）、
        # 题材简称（思乡）→全名（思乡羁旅）
        surface_to_canon = {t2s(s): c for s, c in IMAGERY_SURFACE}
        want_imagery = []
        for x in imagery or []:
            xs = t2s((x or "").strip())
            canon = xs if xs in IMAGERY else surface_to_canon.get(xs, "")
            if canon and canon not in want_imagery:
                want_imagery.append(canon)
        want_themes = []
        for x in themes or []:
            xs = t2s((x or "").strip())
            full = next((th for th in THEMES if xs == th or (len(xs) >= 2 and xs in th)), "")
            if full and full not in want_themes:
                want_themes.append(full)
        want_emotions: List[str] = []
        folded = t2s(mood or "")
        for key, hint in MOOD_HINTS.items():
            if key in folded:
                want_imagery += [x for x in hint["imagery"] if x not in want_imagery]
                want_themes += [x for x in hint["themes"] if x not in want_themes]
                want_emotions += [x for x in hint["emotions"] if x not in want_emotions]
        # 直接意象/情感词命中
        for surface, canon in IMAGERY_SURFACE:
            if surface in folded and canon not in want_imagery:
                want_imagery.append(canon)
        for marker, cat in EMOTION_SURFACE:
            if marker in folded and cat not in want_emotions:
                want_emotions.append(cat)
        for theme, spec in THEMES.items():
            if any(m in folded for m in spec["markers"]) and theme not in want_themes:  # type: ignore[index]
                want_themes.append(theme)

        scored = []
        for p in self.poems:
            s = 0.0
            img_hit = [c for c in want_imagery if c in p.imagery]
            s += 2.0 * len(img_hit)
            th_hit = [t for t in want_themes if t in p.themes]
            s += 3.0 * len(th_hit)
            emo_hit = [e for e in want_emotions if e in p.emotions]
            s += 1.5 * len(emo_hit)
            if s <= 0:
                continue
            if p.source in ("TANG300", "SONGCI300", "QIANJIA") or p.also_in:
                s += 1.0
            scored.append((s, p, img_hit, th_hit, emo_hit))
        scored.sort(key=lambda x: (-x[0], x[1].poem_id))
        recs = []
        for s, p, img_hit, th_hit, emo_hit in scored[:top_k]:
            quote = ""
            surfaces = [sf for c in img_hit for sf in IMAGERY.get(c, [])]
            for ln in p.lines:
                if any(sf in t2s(ln) for sf in surfaces):
                    quote = ln
                    break
            recs.append({
                "poem_id": p.poem_id, "title": p.title, "author": p.author,
                "dynasty": p.dynasty, "genre": p.genre,
                "quote": quote or (p.lines[0] if p.lines else ""),
                "matched_imagery": img_hit, "matched_themes": th_hit,
                "matched_emotions": emo_hit, "score": round(s, 2), "layer": "A",
            })
        return {
            "query": {"mood": mood, "imagery": want_imagery, "themes": want_themes,
                      "emotions": want_emotions},
            "recommendations": recs,
        }

    # ── 对比鉴赏 ─────────────────────────────────────────────────
    def differential(self, refs: List[str]) -> Dict:
        poems = [p for p in (self.resolve_poem(r) for r in refs) if p]
        if len(poems) < 2:
            return {"error": "需要至少两首可解析的作品（poem_id 或《题名》）。"}
        rows = []
        rows.append({"axis": "体裁（B层）", "detail": "；".join(
            f"《{p.title}》{p.genre}（{p.metrics.get('line_count')}句，"
            f"{metrics_mod.char_pattern(p.metrics.get('char_counts', []))}）" for p in poems)})
        img_sets = [set(p.imagery) for p in poems]
        shared = sorted(set.intersection(*img_sets)) if img_sets else []
        rows.append({"axis": "共有意象", "detail": "、".join(shared) or "无"})
        for p, imgs in zip(poems, img_sets):
            uniq = sorted(imgs - set.union(*(s for s in img_sets if s is not imgs))) if len(img_sets) > 1 else sorted(imgs)
            rows.append({"axis": f"《{p.title}》独有意象", "detail": "、".join(uniq) or "无"})
        rows.append({"axis": "题材", "detail": "；".join(
            f"《{p.title}》：{'、'.join(p.themes) or '未判定'}" for p in poems)})
        rows.append({"axis": "情感标记", "detail": "；".join(
            f"《{p.title}》：{'、'.join(p.emotions) or '未检出'}" for p in poems)})
        # 互文
        ids = {p.poem_id for p in poems}
        inter = [r for r in self.intertext_rules
                 if r["source_poem_id"] in ids and r["target_poem_id"] in ids]
        if inter:
            rows.append({"axis": "互文（逐字复用）", "detail": "；".join(
                f"{r['mode']}「{r['shared_span']}」" for r in inter[:3])})
        return {
            "poems": [{"poem_id": p.poem_id, "title": p.title, "author": p.author,
                       "dynasty": p.dynasty, "lines": p.lines} for p in poems],
            "contrast": rows,
        }

    # ── 教学 ─────────────────────────────────────────────────────
    def teach(self, topic: str) -> Dict:
        topic_s = t2s((topic or "").strip())
        # 题材教学（支持简称：思乡/送别/怀古/边塞……）
        for theme, prof in self.theme_profiles.items():
            if theme in topic_s or (len(topic_s) >= 2 and topic_s in theme):
                reps = [{**e, "author": self.by_id[e["poem_id"]].author if e["poem_id"] in self.by_id else ""}
                        for e in prof.get("example_evidence", [])[:6]]
                return {"lesson": {
                    "type": "theme", "topic": theme,
                    "outline": f"题材「{theme}」：{prof.get('definition','')}（语料 {prof.get('n_poems')} 首）",
                    "markers": prof.get("marker_terms", [])[:12],
                    "top_imagery": prof.get("top_imagery", [])[:8],
                    "dynasty_distribution": prof.get("dynasty_distribution", {}),
                    "representative": reps,
                    "exercise": f"练习：从代表作中任选一首，找出指向「{theme}」的标记词并核对原文。",
                }}
        # 体裁教学
        genre_pool = [p for p in self.poems if p.genre == topic_s]
        if genre_pool:
            curated = [p for p in genre_pool if p.source in ("TANG300", "SONGCI300", "QIANJIA") or p.also_in]
            reps = (curated or genre_pool)[:6]
            n = len(genre_pool)
            sample = reps[0]
            pattern = metrics_mod.char_pattern(sample.metrics.get("char_counts", []))
            return {"lesson": {
                "type": "genre", "topic": topic_s,
                "outline": f"体裁「{topic_s}」：语料 {n} 首；典型句式如《{sample.title}》为 {pattern}。"
                           "（体裁判定为 B 层计量近似，语料标签优先。）",
                "representative": [{"poem_id": p.poem_id, "title": p.title, "author": p.author,
                                   "quote": p.lines[0] if p.lines else ""} for p in reps],
                "exercise": "练习：数一数代表作的句数与每句字数，验证体裁判定。",
            }}
        # 意象教学
        for canon in IMAGERY:
            if canon in topic_s:
                prof = self.imagery_profiles.get(canon)
                if prof:
                    return {"lesson": {
                        "type": "imagery", "topic": canon,
                        "outline": f"意象「{canon}」：{prof['n_poems']} 首支撑；"
                                   "情感关联为语料归纳，同一意象可承载相反情感。",
                        "associations": prof.get("emotion_associations", [])[:5],
                        "representative": [
                            {"poem_id": a["example"]["poem_id"], "title": a["example"].get("title", ""),
                             "quote": a["example"]["quote"], "author": ""}
                            for a in prof.get("emotion_associations", [])[:5]],
                        "exercise": f"练习：在代表句中指出「{canon}」的表面形式与同现情感标记。",
                    }}
        # 作者教学
        prof = self.author_profiles.get(topic_s)
        if prof:
            reps = [{**r, "quote": (self.by_id[r["poem_id"]].lines[0] if r["poem_id"] in self.by_id and self.by_id[r["poem_id"]].lines else ""), "author": prof["author"]}
                    for r in prof.get("representative_poems", [])[:6]]
            return {"lesson": {
                "type": "author", "topic": prof["author"],
                "outline": f"诗人「{prof['author']}」（{prof['dynasty']}）：语料 {prof['n_poems']} 首；"
                           f"高频意象 {'、'.join(x['imagery'] for x in prof.get('top_imagery', [])[:5])}。",
                "bio": prof.get("bio", "")[:300],
                "representative": reps,
                "exercise": "练习：任选两首代表作，比较其意象与题材。",
            }}
        return {"error": f"未找到可教学的主题「{topic}」。可选：题材（{'、'.join(list(self.theme_profiles)[:5])}…）、"
                         f"体裁（五绝/七律/词…）、意象（月/柳/雁…）或诗人名。"}

    # ── 作品全息 ─────────────────────────────────────────────────
    def explain_poem(self, ref: str) -> Dict:
        # 同题多作且未指定作者 → 返回消歧候选卡（不猜）
        bare = (ref or "").strip()
        if "@" not in bare and not bare.startswith("CNP_"):
            cands = self.resolve_candidates(bare)
            distinct_authors = {t2s(c.author) for c in cands}
            if len(cands) > 1 and len(distinct_authors) > 1:
                return self.err(
                    "POEM_AMBIGUOUS", f"存在多首同题作品《{bare.strip('《》〈〉')}》，请以 @作者 指定",
                    candidates=[{"poem_id": c.poem_id, "author": c.author, "dynasty": c.dynasty,
                                 "first_line": c.lines[0] if c.lines else "",
                                 "ref": f"《{c.title}》@{c.author}"} for c in cands[:6]])
        p = self.resolve_poem(ref)
        if p is None:
            return self.err("POEM_NOT_FOUND", f"无法解析作品「{ref}」（可用 poem_id 或《题名》@作者）")
        related_intertext = [r for r in self.intertext_rules
                             if p.poem_id in (r["source_poem_id"], r["target_poem_id"])][:6]
        ext = self._ext_by_poem.get(p.poem_id)
        author_prof = self.author_profiles.get(t2s(p.author))
        return {
            "poem": {
                "poem_id": p.poem_id, "title": p.title, "author": p.author,
                "dynasty": p.dynasty, "book": p.book, "cipai": p.cipai,
                "section": p.section, "genre": p.genre, "lines": p.lines,
                "tags": p.tags, "also_in": p.also_in, "layer": "A",
            },
            "metrics": {**metrics_mod.describe(p), "layer": "B"},
            "imagery": p.imagery,
            "emotions": p.emotions,
            "themes": p.themes,
            "notes": [{"text": n, "layer": "C"} for n in p.notes[:20]],
            "appreciation": ({"text": p.appreciation, "layer": "C", "source": "水墨唐诗白话导读"}
                             if p.appreciation else None),
            "author_bio": ({"text": author_prof.get("bio", "")[:400], "layer": "C"}
                           if author_prof and author_prof.get("bio") else None),
            "external_analysis": ({"layer": "D", "dataset": "PoetryMTEB(DeepSeek-V3.1)",
                                   "subject": ext.get("subject"), "theme": ext.get("theme"),
                                   "emotion": ext.get("emotion"),
                                   "note": "外部LLM生成，非本系统结论"} if ext else None),
            "intertext": [{"mode": r["mode"], "shared_span": r["shared_span"],
                           "other": (r["target_poem_id"] if r["source_poem_id"] == p.poem_id
                                     else r["source_poem_id"])} for r in related_intertext],
        }

    # ── 韵伴与互文查询 ────────────────────────────────────────────
    def rhyme_query(self, char: str = "", poem_ref: str = "") -> Dict:
        if poem_ref:
            p = self.resolve_poem(poem_ref)
            if p is None:
                return {"error": f"无法解析作品「{poem_ref}」。"}
            feet = (p.metrics or {}).get("rhyme_feet", [])
            groups = [r for r in self.rhyme_rules if any(t2s(f) in r["members"] for f in feet)]
            return {"poem_id": p.poem_id, "rhyme_feet": feet,
                    "groups": groups[:3], "layer": "B",
                    "note": "韵伴聚类为语料归纳，非平水韵权威表。"}
        ch = t2s((char or "").strip())[:1]
        groups = [r for r in self.rhyme_rules if ch in r["members"]]
        out_groups = []
        for g in groups[:3]:
            g2 = dict(g)
            g2["verse_examples"] = self._rhyme_verse_examples(ch, g)
            out_groups.append(g2)
        return {"char": ch, "groups": out_groups,
                "note": "韵伴聚类为语料归纳，非平水韵权威表。"}

    def _rhyme_verse_examples(self, ch: str, group: Dict, cap: int = 8) -> List[Dict]:
        """从韵组支撑诗中取实押例句：查询字与同组韵伴同诗互押的原句。"""
        members = set(group.get("members") or [])
        out: List[Dict] = []
        for pid in group.get("supporting_poems") or []:
            p = self.by_id.get(pid)
            if p is None:
                continue
            feet_lines: List[Dict] = []
            hit_char = False
            for i, ln in enumerate(p.lines):
                chars = content_only(t2s(ln))
                if not chars or (i % 2 == 0 and len(p.lines) > 2):
                    continue  # 例句取偶数句（韵脚位）；短章不限
                foot = chars[-1]
                if foot in members:
                    feet_lines.append({"line": ln, "foot": foot})
                    if foot == ch:
                        hit_char = True
            if hit_char and len(feet_lines) >= 2:
                out.append({"poem_id": p.poem_id, "title": p.title, "author": p.author,
                            "dynasty": p.dynasty,
                            "rhyming_lines": feet_lines[:4]})
            if len(out) >= cap:
                break
        return out

    # ── 诗人别名 / 词牌全景 / 意象全量例证 / 飞花令 ────────────────
    def resolve_author(self, name: str) -> Dict:
        """诗人名解析：直接命中 → 字号别名（苏东坡→苏轼）→ 建议列表。"""
        from ..lexicon import canonical_author
        raw = t2s((name or "").strip())
        if raw in self.author_profiles:
            return {"status": "unique", "author": raw, "via": ""}
        canon = canonical_author(raw)
        if canon != raw and canon in self.author_profiles:
            return {"status": "unique", "author": canon, "via": f"别名归并：{raw}→{canon}"}
        sugg = [a for a in self.author_profiles if raw and raw in a][:8]
        return {"status": "not_found", "author": "", "suggestions": sugg}

    def cipai_query(self, name: str) -> Dict:
        """词牌全景：龙谱权威层 + 语料归纳定格 + 全部例词（可点击）。"""
        from ..corpus.cipu import cipu_index
        from ..lexicon import CIPAI_ALIAS_GROUPS
        q = t2s((name or "").strip())
        if not q:
            return {"error": {"code": "EMPTY_QUERY", "message": "请给出词牌名", "recoverable": True}}
        if not hasattr(self, "_cipu_idx"):
            self._cipu_idx = cipu_index()
        pu = self._cipu_idx.get(q)
        # 语料归纳档案：精确 → 别名组内互查 → 键内子串（语料键多为「望江南・忆江南」复合名）
        prof = self.cipai_profiles.get(q)
        via = ""
        if prof is None:
            candidates = {q}
            for grp in CIPAI_ALIAS_GROUPS:
                if q in grp:
                    candidates.update(grp)
            if pu:
                candidates.add(t2s(pu["cipai"]))
                candidates.update(t2s(a) for a in pu.get("aliases") or [])
            best = None
            for key, r in self.cipai_profiles.items():
                if any(c == key or c in key for c in candidates):
                    if best is None or r["n_poems"] > best[1]["n_poems"]:
                        best = (key, r)
            if best:
                prof, via = best[1], (f"同调异名归并：{q}→{best[0]}" if best[0] != q else "")
        all_poems = []
        if prof:
            for pid in prof.get("supporting_poems") or []:
                p = self.by_id.get(pid)
                if p:
                    all_poems.append({"poem_id": pid, "title": p.title,
                                      "author": p.author, "dynasty": p.dynasty})
        if pu is None and prof is None:
            avail = [k for k in self.cipai_profiles if q and (q in k or k in q)][:8]
            return {"error": {"code": "CIPAI_NOT_FOUND", "message": f"无词牌「{q}」的词谱或语料档案",
                              "recoverable": True, "candidates": avail}}
        return {"query": q, "resolved_via": via,
                "cipu": pu,   # 词谱权威层（龙榆生），可为 None
                "cipai_profile": prof,  # 语料归纳层，可为 None
                "all_poems": all_poems,
                "note": "词谱层为龙榆生《唐宋词格律》权威谱；定格层为语料归纳（众数句式），"
                        "两层并列互证；例词为语料全部支撑作品。"}

    def imagery_examples(self, name: str) -> Dict:
        """意象全量例证：从支撑规则回溯全部作品，附命中原句，可点击回源。"""
        canon = t2s((name or "").strip())
        prof = self.imagery_profiles.get(canon)
        if prof is None:
            return {"error": f"无意象档案「{canon}」", "available": list(self.imagery_profiles)}
        surfaces = sorted({t2s(s) for s in (prof.get("surface_forms") or [canon])},
                          key=len, reverse=True)
        pids: List[str] = []
        seen = set()
        for rid in prof.get("supporting_initial_rules") or []:
            stem = rid.replace("IR_", "", 1).rsplit("_", 1)[0]
            if stem not in seen:
                seen.add(stem)
                pids.append(stem)
        examples = []
        for pid in pids:
            p = self.by_id.get(pid)
            if p is None:
                continue
            quote = next((ln for ln in p.lines
                          if any(s in t2s(ln) for s in surfaces)), "")
            examples.append({"poem_id": pid, "title": p.title, "author": p.author,
                             "dynasty": p.dynasty, "quote": quote})
        return {"imagery": canon, "n_total": prof.get("n_poems"),
                "n_listed": len(examples), "examples": examples,
                "note": ("全量例证按支撑规则回溯"
                         + ("；档案存证上限内列出，总支撑数以 n_total 为准"
                            if prof.get("n_poems", 0) > len(examples) else ""))}

    def feihua(self, char: str, exclude_ids: Optional[List[str]] = None,
               user_line: str = "", round_no: int = 0) -> Dict:
        """飞花令：校验用户句（须语料实有且含令字），并回一句未用过的应对。"""
        from ..textutil import contains_verbatim, cjk_chars
        ch = t2s((char or "").strip())[:1]
        if not ch:
            return {"error": {"code": "EMPTY_CHAR", "message": "请给出令字（单字）",
                              "recoverable": True}}
        exclude = set(exclude_ids or [])
        out: Dict = {"char": ch}
        if user_line and user_line.strip():
            ul = user_line.strip()
            folded = "".join(cjk_chars(t2s(ul)))
            check: Dict = {"line": ul, "valid": False, "reason": ""}
            if ch not in folded:
                check["reason"] = f"句中不含令字「{ch}」"
            elif len(folded) < 4:
                check["reason"] = "句子过短（至少四字）"
            else:
                hit = None
                for h in self.rag.search(ul, top_k=5):
                    p = self.by_id.get(h["poem_id"])
                    if p and contains_verbatim(p.text, ul):
                        hit = p
                        break
                if hit is None:
                    check["reason"] = "语料未见此句（须原句实有，简繁不限）"
                else:
                    check.update(valid=True, poem_id=hit.poem_id, title=hit.title,
                                 author=hit.author, dynasty=hit.dynasty)
                    exclude.add(hit.poem_id)
            out["user_check"] = check
        # 应对句：确定性遍历（按令字+轮次错开起点），取含令字的完整原句；
        # 首选诗/词体，元曲科白味句子仅在无诗词可用时兜底
        reply = fallback = None
        n = len(self.poems)
        start = (hash((ch, int(round_no))) % n + n) % n
        for k in range(n):
            p = self.poems[(start + k) % n]
            if p.poem_id in exclude:
                continue
            for ln in p.lines:
                folded = t2s(ln)
                if ch in folded and 4 <= len(content_only(folded)) <= 12:
                    cand = {"poem_id": p.poem_id, "title": p.title, "author": p.author,
                            "dynasty": p.dynasty, "line": ln}
                    if "曲" in (p.genre or "") or p.source == "YUANQU":
                        fallback = fallback or cand
                    else:
                        reply = cand
                    break
            if reply:
                break
        reply = reply or fallback
        out["reply"] = reply
        out["note"] = ("飞花令规则：轮流吟出含令字的语料原句，已用作品不重复；"
                       "本系统应对句均为语料原句（poem_id 可回源）。"
                       + ("" if reply else f"语料中含「{ch}」的未用句已尽，此轮认负。"))
        return out

    def intertext_query(self, poem_ref: str = "", text: str = "") -> Dict:
        if poem_ref:
            p = self.resolve_poem(poem_ref)
            if p is None:
                return {"error": f"无法解析作品「{poem_ref}」。"}
            pairs = [r for r in self.intertext_rules
                     if p.poem_id in (r["source_poem_id"], r["target_poem_id"])]
            return {"poem_id": p.poem_id, "pairs": pairs[:10]}
        if text:
            from ..textutil import content_only
            folded = content_only(t2s(text))
            pairs = [r for r in self.intertext_rules if folded and folded in r["shared_span"]]
            if not pairs:
                hits = self.rag.search(text, top_k=5)
                return {"text": text, "pairs": [], "nearest_poems": hits,
                        "note": "无逐字互文命中，给出最近似检索结果。"}
            return {"text": text, "pairs": pairs[:10]}
        return {"error": "需提供 poem_ref 或 text。"}

    # ── 字义训诂（C层：说文解字 + 尔雅，gujilab CC0）──────────────
    def gloss_query(self, chars: str = "", poem_ref: str = "") -> Dict:
        targets: List[str] = []
        context = ""
        if poem_ref:
            p, err = self.require_unique(poem_ref)
            if err:
                return err
            context = p.poem_id
            from collections import Counter as _C
            from ..textutil import cjk_chars
            freq = _C(cjk_chars(p.text))
            targets = [c for c, _ in freq.most_common(8)]
        else:
            from ..textutil import cjk_chars
            targets = cjk_chars(chars)[:8]
        if not targets:
            return {"error": "需提供 chars（1-8 个汉字）或 poem_ref。"}
        entries = []
        for ch in targets:
            key = t2s(ch)
            sw = self.shuowen.get(key) or self.shuowen.get(ch)
            erya_hits = [self.erya[i] for i in self._erya_index.get(key, [])[:3]]
            entries.append({
                "char": ch,
                "shuowen": ({"headword": sw["char"], "radical": sw.get("radical", ""),
                             "fanqie": sw.get("fanqie", ""), "gloss": sw.get("gloss", "")}
                            if sw else None),
                "erya": [{"chapter": g["chapter"], "members": g["members"][:12],
                          "gloss": g["gloss"]} for g in erya_hits],
            })
        return {"glosses": entries, "poem_id": context, "layer": "C",
                "source": "说文解字/尔雅（gujilab/chinese-classical-corpus，CC0）",
                "note": "训诂为字书本义，诗中用义可能引申；本层为 C 层旁证。"}

    # ── 诗境（进入一首诗：逐句多层注解 + 情感曲线）─────────────────
    def scene(self, ref: str) -> Dict:
        p, err = self.require_unique(ref)
        if err:
            return err
        from ..extract.annotate import annotate_line
        from ..extract.phonology import get_phonology
        from ..induce.allusions import detect_allusions
        ph = get_phonology()
        lines_out, curve = [], []
        for i, ln in enumerate(p.lines):
            h = annotate_line(ln, i)
            pat = "".join(ph.line_pattern(ln)) if ph.ready else ""
            pos = len(h.emotions)
            neg = len(h.negated_emotions)
            curve.append(pos - neg)
            lines_out.append({
                "line": ln, "index": i + 1, "tone_pattern": pat,
                "imagery": [c for c, _ in h.imagery],
                "emotions": [c for c, _ in h.emotions],
                "negated": [c for c, _ in h.negated_emotions],
                "allusions": detect_allusions(ln),
            })
        duizhang = []
        if len(p.lines) == 8:
            from ..extract.couplet import analyze_regulated
            duizhang = analyze_regulated(p.lines)
        return {"poem": {"poem_id": p.poem_id, "title": p.title, "author": p.author,
                         "dynasty": p.dynasty, "genre": p.genre},
                "lines": lines_out, "emotion_marker_density": curve,
                "couplets": duizhang, "layer_legend": config.LAYER_LABEL,
                "note": "逐句标注均为确定性层（A字面/B音韵/种子典故候选）。"
                        "emotion_marker_density 为情感词表命中密度（正向计数−否定计数），"
                        "不是效价/唤醒度等真实情感维度——篇章情感建模见路线图。"}

    # ── 研究端 ───────────────────────────────────────────────────
    def research(self, topic: str = "") -> Dict:
        try:
            net = json.loads((config.NETWORK_DIR / "imagery_network.json").read_text(encoding="utf-8"))
            dyn = json.loads((config.NETWORK_DIR / "dynasty_tables.json").read_text(encoding="utf-8"))
            mat = json.loads((config.NETWORK_DIR / "emotion_imagery_matrix.json").read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"error": "研究资产未生成，请先运行 pipeline。"}
        out = {"imagery_network_top": {"nodes": net["nodes"][:20], "edges": net["edges"][:20]},
               "dynasty_poem_counts": dyn["poem_counts"],
               "emotion_imagery_matrix": {k: v for k, v in list(mat.items())[:6]}}
        topic_s = t2s(topic or "")
        for canon in IMAGERY:
            if canon in topic_s and canon in self.imagery_profiles:
                out["focus_imagery"] = self.imagery_profiles[canon]
                break
        return out


_engine: Optional[Engine] = None


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = Engine()
    return _engine


def set_engine(engine: Optional[Engine]) -> None:
    global _engine
    _engine = engine
